﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


namespace PagingApi.Controllers
{
    [Route("api/customers")]
    [ApiController]
    public partial class CustomerController : ControllerBase
    {

        [HttpGet]
        [AllowAnonymous]
        public  async Task<IActionResult> GetEmployee(string skip, string take)
        {
            List<Customer> customers = new List<Customer>();
            try
            {
                #region test
                //employees.Add(new Employee(1, "Govind Raj", "Business Analyst"));
                //employees.Add(new Employee(2, "Krishn Mahato", "Development"));
                //employees.Add(new Employee(3, "Bob Ross", "Testing"));
                //employees.Add(new Employee(4, "Steve Davis", "Development"));
                //employees.Add(new Employee(5, "Dave Tucker", "Infrastructure"));
                //employees.Add(new Employee(6, "James Anderson", "HR"));

                //employees.Add(new Employee(7, "James Anderson1", "HR"));
                //employees.Add(new Employee(8, "James Anderson2", "HR"));
                //employees.Add(new Employee(9, "James Anderson3", "HR"));
                //employees.Add(new Employee(10, "James Anderson4", "HR"));
                //employees.Add(new Employee(11, "James Anderson5", "HR"));
                //employees.Add(new Employee(12, "James Anderson6", "HR"));
                //employees.Add(new Employee(13, "James Anderson7", "HR"));
                //employees.Add(new Employee(14, "James Anderson8", "HR"));
                //employees.Add(new Employee(15, "James Anderson9", "HR"));
                //employees.Add(new Employee(16, "James Anderson0", "HR"));
                //employees.Add(new Employee(17, "James Anderson11", "HR"));
                //employees.Add(new Employee(18, "James Anderson12", "HR"));


                //var data1 = employees.Skip(Convert.ToInt32(skip)).Take(Convert.ToInt32(take));
                //int count = employees.Count;
                //return Ok(new EmployeeResponse { Count = count, Employees = data1 }); 
                #endregion

                var parameters = new DynamicParameters();
                parameters.Add("@take", take);
                parameters.Add("@skip", skip);
                parameters.Add("@Count", dbType: DbType.Int64, direction: ParameterDirection.Output);

                var data = await ExecuteStoredProc(parameters);
                return Ok(data);

            }
            catch (Exception ex)
            {
                return Ok(new CustomerResponse{ Count = 0, customers = customers });
            }
        }

        public async Task<CustomerResponse> ExecuteStoredProc(DynamicParameters parameters)
        {
            List<Customer> customers = new List<Customer>();

            try
            {
                using (IDbConnection db = new SqlConnection("connectionstring"))
                {
                    var sp = "[schemaname].[uspCustomerForPaging]";
                    var list = await db.QueryAsync<Customer>(sp, commandType: CommandType.StoredProcedure,param:parameters);
                    var count = parameters.Get<dynamic>("Count");


                    return new CustomerResponse { Count = count, customers = list };
                }
            }
            catch (Exception ex)
            {
                return new CustomerResponse { Count = 0, customers = customers };
            }

        }
    }
}
