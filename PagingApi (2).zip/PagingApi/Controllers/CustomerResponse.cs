﻿using System.Collections.Generic;

namespace PagingApi.Controllers
{
    public class CustomerResponse
    {
        public IEnumerable<Customer> customers { get; set; }

        public long Count { get; set; }
    }
}
