﻿namespace PagingApi.Controllers
{
    //public class Employee
    //{
    //    public Employee(long Id, string Name, string Designation)
    //    {
    //        this.EmployeeID = Id;
    //        this.EmployeeName = Name;
    //        this.Designation = Designation;

    //    }
    //    public long EmployeeID { get; set; }
    //    public string EmployeeName { get; set; }
    //    public string Designation { get; set; }
    //}

    public class Customer
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
    }
}
