/***
Test sp for customer pagination
--***/

-- exec [MasterData].[uspCustomerForPaging] 10,20,0
CREATE PROCEDURE [MasterData].[uspCustomerForPaging]
    @take INT = 10,
    @skip INT = 0,
    @Count BIGINT OUTPUT
AS
BEGIN
    SET XACT_ABORT, NOCOUNT ON;
    BEGIN TRY
        SELECT o.ID,
               o.Name,
               o.Number
        FROM MasterData.Customer o
        WHERE o.ID > 0
        ORDER BY o.ID 
		OFFSET @skip ROWS -- skip 10 rows
        FETCH NEXT @take ROWS ONLY; -- take 10 rows
        SET @Count =
        (
            SELECT COUNT(1) FROM MasterData.Customer
        );

    END TRY
    BEGIN CATCH
        IF (@@TRANCOUNT > 0)
            ROLLBACK TRANSACTION;
        RETURN 55555;
    END CATCH;
END;
GO


